#include"dna.h"
#include"grades.h"
#include"string.h"
#include"reciept.h"
using namespace std;
#include<iostream>

int main() 
{
	/*string dna = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC";
	std::cout << "DNA Count" << "\n";
	vector <int> show_dna =count_dna(dna);
	cout << "A " << show_dna[0]<< endl;
	cout << "C " << show_dna[1] << endl;
	cout << "G " << show_dna[2] << endl;
	cout << "T " << show_dna[3] << endl;
		
	
	cin.get();*/
	/*vector<int>grade_list{ 90,90,90,90, 82,80,80,80,70,72,70,75,71,60,62,62,65,20,30,40 };
	vector<int>show_grade = sort_grades(grade_list);
	cout << "Here are the grade" << "\n";
	cout << "_______________________________" << endl;
	
	cout << "A" <<" | " << show_grade[0]<< endl;
	cout << "B" <<" | " << show_grade[1] << endl;
	cout << "C" <<" | " << show_grade[2] << endl;
	cout << "D" <<" | " << show_grade[3] << endl;
	cout << "F" <<" | " << show_grade[4] <<"|"<< endl;
	cout << "______________________________" << endl;
	cin.get();
	*/
	Reciept a;
	Reciept b;
	Reciept c;
	Reciept result;
	
	vector<Reciept>show_reciept{ a,b,c };
	for (auto r : show_reciept) 
	{
		std::cin >> a;
		result += a;


	}
	
	cout << result;
	system("pause");
	
	string name= "George";
	cout << name << endl;
	
	reverse_string(name);
	cout << name;
	cout << endl;
	system("pause");

	return 0;
}