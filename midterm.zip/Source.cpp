//#include<iostream>
//#include<string>
//using namespace std;
//
//std::string change_char(std::string input);
//string reverse_string(const string& str);
//
//std::string change_char(std::string input) 
//{
//	for (std::size_t i = 0; i < input.size(); i++) 
//	{
//		switch (input[i])
//		{ case 'A':
//			input[i] = 'T';
//			break;
//
//		case 'T':
//			input[i] = 'A';
//			break;
//
//		case'G':
//			input[i] = 'C';
//			break;
//		case'C':
//			input[i] = 'G';
//			break;
//
//
//		default:
//			break;
//		}
//
//	}
//	return reverse_string(input);
//
//}
//string reverse_string(const string& str) 
//{
//	string  reverses;
//	for (size_t i = str.size() - 1; i != -1; --i) 
//	{
//		reverses.push_back(str[i]);
//	}
//	return reverses;
//}
//int main() 
//{
//	auto dna =change_char( "TTTGGGAACCC");
//	auto dna2 = reverse_string(dna);
//	std::cout << dna << "\n";
//	cout << dna2;
//	cin.get();
//
//}
//
