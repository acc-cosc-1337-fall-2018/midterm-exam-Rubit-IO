#include<iostream>
#include<vector>
using namespace std;

vector<int > sort_grades(vector <int> grades);
