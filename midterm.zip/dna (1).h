#include<iostream>
#include<vector>
#include<string>

using namespace std;


vector<int>count_dna(string dna);
