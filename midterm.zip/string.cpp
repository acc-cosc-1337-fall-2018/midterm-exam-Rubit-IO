#include "string.h"

void reverse_string(string str)
{
	string reverse_str;
	for (int i = str.size() ; i != -1; i--) 
	{
		reverse_str+=(str[i]);
	}
	reverse_str;

}

