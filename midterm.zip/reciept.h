#ifndef RECIEPT_H
#define RECIEPT_H
#include<iostream>
#include<string>
using namespace std;
class Reciept
{
public:
	Reciept() = default;
	Reciept(double a) :amount(a) {};
	friend std::istream& operator>>(std::istream& in, Reciept& b);//overwrite >>
	friend std::ostream & operator<<(std::ostream& out, Reciept & d);
	Reciept operator+=(const Reciept & i2);
	



private:
	double amount{ 0 };
	double get_total(double a)const;
	double get_tip(double a) const;
	double get_tax(double a) const;
	
	 
	
};


#endif // !RECIEPT_H

