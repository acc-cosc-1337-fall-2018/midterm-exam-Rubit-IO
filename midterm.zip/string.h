#include<iostream>
#include<string>
using namespace std;

void reverse_string(string str);

