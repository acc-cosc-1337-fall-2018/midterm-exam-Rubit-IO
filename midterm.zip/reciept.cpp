#include "reciept.h"


Reciept Reciept::operator+=(const Reciept & i2)
{
	amount += i2.amount;
	return Reciept(amount);
}

double Reciept::get_tip(double a) const
{
	return a / 5;
}

//double Reciept::get_total(double a) const
//{
//	return 0.0;
//}

double Reciept::get_tax(double a) const
{
	return a / 10;
}

std::istream & operator>>(std::istream & in, Reciept & b)
{
	double value{ 0 };
	std::cout << "Enter the item value:     " << endl;
	in >> b.amount;
	return in;
}

Reciept operator+=(const Reciept & i, const Reciept & i2)
{
	Reciept final;
	return Reciept();
}

std::ostream & operator<<(std::ostream & out, Reciept & d)
{
	out << "Bill amount:          " << d.amount << endl;
	out << "Tip amount:            " << d.get_tip(d.amount) << endl;
	out << "Tax amount:            " << d.get_tax(d.amount) << endl;
	out << "_______________________" << endl;
	out << "total Amount             " << d.get_total(d.amount) << endl;
	return out;
}

double Reciept::get_total(double a) const
{
	double total{ 0 };
	total += a;
	total += get_tip(a);
	total += get_tax(a);
	return total;
}

//std::ostream & operator<<(std::istream & in, Reciept & d)
//{
//	// TODO: insert return statement here
//}
